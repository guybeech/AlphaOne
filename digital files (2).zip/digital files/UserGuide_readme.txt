On this disk you will find the dissertation in both Word and PDF format and the following folders:

'RetrievalOfAstronomicalData' - which contains the source code of the ROAD software, developed on the Visual Studio 2013 Ultimate IDE. The software needs to be run within this IDE.

'roadlogs' - containing a queryResult document and application run screenshots. Also for each test run: log outputs and xml documents.

'outputs' -  within 'roadlogs' folder this contains the output files produced for the five test runs undertaken and also the two PDF files which were produced from the two XSL-FO output files.

Note: To successfully run this software from the campus network the following lines of code need to be uncommented by removing '//' from in front of them to handle the proxy server, otherwise the database queries will not succeed.
In the class 'Query.cs':
  In method 'getOecData'
      //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
      //request.Proxy = webproxy;
  In method 'getOecXmlData'
      //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
      //request.Proxy = webproxy;
  In method 'getMastData'
      //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
      //request.Proxy = webproxy;
  In method 'getSimbadData'
      //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
      //request.Proxy = webproxy;