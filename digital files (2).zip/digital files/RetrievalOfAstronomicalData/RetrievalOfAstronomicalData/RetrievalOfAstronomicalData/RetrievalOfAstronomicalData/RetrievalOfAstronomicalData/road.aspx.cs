﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Xml.Linq;

namespace RetrievalOfAstronomicalData {
    public partial class road : System.Web.UI.Page {
        // CENTRALISED VARIABLES
        private SortedList chosenDatasources;
        private SortedList queryResults;
        private SortedList chosenOutputs;
        private Query dataQueries;
        private StreamWriter sw;
        private XmlDocument resultsXmlDoc;
        private QueryTransform transformResults;
        private OutputTransform createChosenOutputs;


        protected void Page_Load(object sender, EventArgs e) {
            // DATASOURCE CHOICES FOR THE USER
            if (ddlDatabases.Items.Count == 0) {
                ddlDatabases.Items.Add(new ListItem("Mast", "http://archive.stsci.edu/hst/search.php?RA=01.44&DEC=-15.56&radius=100.&max_records=10&outputformat=CSV&action=Search"));
                ddlDatabases.Items.Add(new ListItem("Simbad", "http://simbad.u-strasbg.fr/simbad/sim-coo?output.format=HTML&Coord=01 44 -15 56&Radius=10&Radius.unit=arcmin"));
                ddlDatabases.Items.Add(new ListItem("OEC", "http://www.openexoplanetcatalogue.com/planet/tau%20Ceti%20d/"));
                ddlDatabases.Items.Add(new ListItem("OEC_XML", "http://www.openexoplanetcatalogue.com/open_exoplanet_catalogue/systems/tau%20Ceti.xml"));
            }
            queryResults = new SortedList();

            // OUTPUT CHOICES FOR THE USER
            if (ddlChosenOutputs.Items.Count == 0) {
                ddlChosenOutputs.Items.Add(new ListItem("PDF", "PDF"));
                ddlChosenOutputs.Items.Add(new ListItem("HTML", "HTML"));
                ddlChosenOutputs.Items.Add(new ListItem("Machine", "Machine"));
            }
            chosenOutputs = new SortedList();
        }


        /// <summary>
        /// Adds selected database to the list of selected databases
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSelectDatabase_Click(object sender, EventArgs e) {
            ListItem lstItem = new ListItem(ddlDatabases.SelectedItem.Text, ddlDatabases.SelectedItem.Value);
            if (!lstSelectedDatabases.Items.Contains(lstItem)) {
                lstSelectedDatabases.Items.Add(lstItem);
            }
        }


        /// <summary>
        /// Removes selected database from the list of selected databases
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeselectDatabase_Click(object sender, EventArgs e) {
            ListItem lstItem = new ListItem(ddlDatabases.SelectedItem.Text, ddlDatabases.SelectedItem.Value);
            lstSelectedDatabases.Items.Remove(lstItem);
        }


        /// <summary>
        /// Removes selected output from the list of selected outputs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeselectOutput_Click(object sender, EventArgs e) {
            ListItem lstItem = new ListItem(ddlChosenOutputs.SelectedItem.Text, ddlChosenOutputs.SelectedItem.Value);
            lstSelectedOutputs.Items.Remove(lstItem);
        }


        /// <summary>
        /// Adds selected database to the list of selected outputs
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSelectOutput_Click(object sender, EventArgs e) {
            ListItem lstItem = new ListItem(ddlChosenOutputs.SelectedItem.Text, ddlChosenOutputs.SelectedItem.Value);
            if (!lstSelectedOutputs.Items.Contains(lstItem)) {
                lstSelectedOutputs.Items.Add(lstItem);
            }
        }


        /// <summary>
        /// Retrieves data from the list of selected databases
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRetrieval_Click(object sender, EventArgs e) {
            txtLog.Text = "";
            // CREATE NEW TEXT FILE EACH TIME PROCESS IS RUN
            string timeStr = DateTime.Now.ToString();
            timeStr = timeStr.Replace("/", " ");
            timeStr = timeStr.Replace(":", "-");
            // Incorporate date time into file name
            string path = "C://roadLogs//myTest_" + timeStr + ".txt";
            // Create new folder if not exists.
            if (Directory.Exists("C://roadLogs") == false) {
                DirectoryInfo dir = Directory.CreateDirectory("C://roadLogs");
            }
            // Create a new stream to write to the text log file
            sw = File.AppendText(path);
            sw.WriteLine("==========================================");
            sw.WriteLine("ROADS beginning data retrieval " + DateTime.Now);
            sw.WriteLine("==========================================");
            sw.Flush();
            txtLog.Text = txtLog.Text + ("==========================================") + "\n";
            txtLog.Text = txtLog.Text + ("ROADS beginning data retrieval " + DateTime.Now) + "\n";
            txtLog.Text = txtLog.Text + ("==========================================") + "\n";

            // GET DATA
            chosenDatasources = new SortedList();
            dataQueries = new Query();
            IEnumerator datasourcesEnum = lstSelectedDatabases.Items.GetEnumerator();
            while (datasourcesEnum.MoveNext()) {
                ListItem datasourcesItem = (ListItem)datasourcesEnum.Current;
                chosenDatasources.Add(datasourcesItem.Text, datasourcesItem.Value);
            }
            queryResults = dataQueries.queryAllSelectedDatasources(chosenDatasources, sw);
            sw.WriteLine("");
            sw.WriteLine("Query results returned");
            txtLog.Text = txtLog.Text + ("") + "\n";
            txtLog.Text = txtLog.Text + ("Query results returned") + "\n";

            // CREATE THE XML DOCUMENT AND TEST FOR SCHEMA COMPLIANCE
            transformResults = new QueryTransform();
            resultsXmlDoc = transformResults.transformIntoXmlDoc(queryResults, sw);
            txtLog.Text = txtLog.Text + ("XMLDocument created") + "\n";

            // =========================================================================================================================
            // NOTE: This validation code (somewhat altered) taken originally from: https://msdn.microsoft.com/en-GB/library/bb387037.aspx  on 24-0202015
            // =========================================================================================================================
            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add("", "C://ROAD//RetrievalOfAstronomicalData//RetrievalOfAstronomicalData//RetrievalOfAstronomicalData//astronomy.xsd");
            XDocument xdocResults = XDocument.Parse(resultsXmlDoc.OuterXml);
 
            bool errors = false;
            xdocResults.Validate(schemas, (o, ve) => {
                sw.WriteLine("{0}", ve.Message);
                errors = true;
            });

            sw.WriteLine("resultsXmlDoc {0}", errors ? "did not validate" : "validated");
            sw.WriteLine();           
            // =========================================================================================================================

            // Output XMLDocument to file
            resultsXmlDoc.Save("C://roadLogs//resultsXmlDocument_" + timeStr + ".xml");
            sw.WriteLine("");
            sw.WriteLine("XMLDocument created: " + "C://roadLogs//resultsXmlDocument_" + timeStr + ".xml");
            txtLog.Text = txtLog.Text + ("Saved to: C://roadLogs//resultsXmlDocument_" + timeStr + ".xml") + "\n";
            txtLog.Text = txtLog.Text + ("") + "\n";

            if (!errors) { 
            // IF VALIDATED, OUTPUT THE DATA IN CHOSEN FILE TYPES - ELSE output Error to log file 
                chosenOutputs = new SortedList();
                IEnumerator outChoicesEnum = lstSelectedOutputs.Items.GetEnumerator();
                while (outChoicesEnum.MoveNext()) {
                    ListItem outChoicesItem = (ListItem)outChoicesEnum.Current;
                    chosenOutputs.Add(outChoicesItem.Text, outChoicesItem.Value);
                }
               
                createChosenOutputs = new OutputTransform();
                createChosenOutputs.createOutputs(chosenOutputs, resultsXmlDoc, sw);

                sw.WriteLine("");
                sw.WriteLine("Outputs produced");
                txtLog.Text = txtLog.Text + ("") + "\n";
                txtLog.Text = txtLog.Text + ("Outputs produced") + "\n";          
            }
            else {
                sw.WriteLine("");
                sw.WriteLine("*** Error *** No file outputs due to XMLDocument schema validation error");
                txtLog.Text = txtLog.Text + ("No file outputs due to XMLDocument schema validation error");
                txtLog.Text = txtLog.Text + ("") + "\n";
            }

            sw.WriteLine("==========================================");
            sw.WriteLine("ROADS finished data retrieval " + DateTime.Now);
            sw.WriteLine("==========================================");
            sw.Flush();
            sw.Close();
            txtLog.Text = txtLog.Text + ("==========================================") + "\n";
            txtLog.Text = txtLog.Text + ("ROADS finished data retrieval " + DateTime.Now) + "\n";
            txtLog.Text = txtLog.Text + ("==========================================") + "\n";
        }

    }
}
