﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

/// <summary>
/// Carries out data transform from SortedList into an XMLDocument
/// </summary>
public class QueryTransform {
    // CENTRALISED VARIABLES
    XmlDocument resultsXmlDoc;
    string resultsXmlStr = "";
    IEnumerator resultsEnum;

    public QueryTransform() {
    }

    /// <summary>
    /// Transforms data from SortedList into a single XMLDocument
    /// </summary>
    /// <param name="queryResults"></param>
    /// <param name="sw"></param>
    /// <returns>resultsXmlDoc</returns>
    public XmlDocument transformIntoXmlDoc(SortedList queryResults, StreamWriter sw) {
        // Convert each datasource item and enter into xml document

        resultsEnum = queryResults.GetEnumerator();
        string resultStr = "";
        while (resultsEnum.MoveNext()) {
            DictionaryEntry deQuery = (DictionaryEntry)resultsEnum.Current;
            string keyStr = deQuery.Key.ToString();
            string valueStr = deQuery.Value.ToString();

            if (keyStr.Equals("Mast")) {
                // Transform MAST results and add to xml document string
                try {
                    // Create an XPathDocument using the XML string
                    StringReader stream = new StringReader(valueStr);
                    XPathDocument xpathDoc = new XPathDocument(stream);
                    // Create the new transform object
                    XslCompiledTransform transform = new XslCompiledTransform();

                    // Collect the resulting transformed XML in StringBuilder object
                    StringBuilder resultString = new StringBuilder();
                    XmlWriter writer = XmlWriter.Create(resultString);
                    transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\mastQuery.xslt");
                    transform.Transform(xpathDoc, writer);

                    // String to store the resulting transformed XML
                    resultStr = resultString.ToString();
                    resultStr = resultStr.Replace("utf-16", "utf-8");

                    // Add to resultsXmlStr
                    if (resultsXmlStr.Equals("")) resultsXmlStr = resultStr;
                    else {
                        // Insert into existing text string
                        resultStr = resultStr.Substring(resultStr.IndexOf("<observationalastronomy>"),
                                                       (resultStr.IndexOf("</observationalastronomy>") + 25) - resultStr.IndexOf("<observationalastronomy>"));
                        resultsXmlStr = resultsXmlStr.Substring(0, resultsXmlStr.IndexOf("<observationalastronomy>")) +
                                        resultStr +
                                        resultsXmlStr.Substring(resultsXmlStr.IndexOf("<observationalastronomy>"));
                    }
                }
                catch (System.Exception ex) {
                    sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On transformIntoXmlDoc 'Mast transform' *** Exception: "
                                                         + ex.Message + " *** "
                                                         + ex.StackTrace);
                    sw.Flush();
                }
            }
            if (keyStr.Equals("Simbad")) {
                // Transform SIMBAD results and add to resultsXmlStr
                try {
                    // Create an XPathDocument using the XML string
                    StringReader stream = new StringReader(valueStr);
                    XPathDocument xpathDoc = new XPathDocument(stream);
                    // Create the new transform object
                    XslCompiledTransform transform = new XslCompiledTransform();

                    // Collect the resulting transformed XML in StringBuilder object
                    StringBuilder resultString = new StringBuilder();
                    XmlWriter writer = XmlWriter.Create(resultString);
                    transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\simbadQuery.xslt");
                    transform.Transform(xpathDoc, writer);

                    // String to store the resulting transformed XML
                    resultStr = resultString.ToString();
                    resultStr = resultStr.Replace("utf-16", "utf-8");

                    // Add to resultsXmlStr
                    if (resultsXmlStr.Equals("")) resultsXmlStr = resultStr;
                    else {
                        // Insert into existing text string
                        resultStr = resultStr.Substring(resultStr.IndexOf("<observationalastronomy>"),
                                                       (resultStr.IndexOf("</observationalastronomy>") + 25) - resultStr.IndexOf("<observationalastronomy>"));
                        resultsXmlStr = resultsXmlStr.Substring(0, resultsXmlStr.IndexOf("<observationalastronomy>")) +
                                        resultStr +
                                        resultsXmlStr.Substring(resultsXmlStr.IndexOf("<observationalastronomy>"));
                    }
                }
                catch (System.Exception ex) {
                    sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On transformIntoXmlDoc 'Simbad transform' *** Exception: "
                                                         + ex.Message + " *** "
                                                         + ex.StackTrace);
                    sw.Flush();
                }
            }
            if (keyStr.Equals("OEC")) {
                // Transform OAC results and add to resultsXmlStr
                try {
                    // Create an XPathDocument using the XML string
                    StringReader stream = new StringReader(valueStr);
                    XPathDocument xpathDoc = new XPathDocument(stream);
                    // Create the new transform object
                    XslCompiledTransform transform = new XslCompiledTransform();

                    // Collect the resulting transformed XML in StringBuilder object
                    StringBuilder resultString = new StringBuilder();
                    XmlWriter writer = XmlWriter.Create(resultString);
                    transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\oecQuery.xslt");
                    transform.Transform(xpathDoc, writer);

                    // String to store the resulting transformed XML
                    resultStr = resultString.ToString();
                    resultStr = resultStr.Replace("utf-16", "utf-8");

                    // Add to resultsXmlStr
                    if (resultsXmlStr.Equals("")) resultsXmlStr = resultStr;
                    else {
                        // Insert into existing text string
                        resultStr = resultStr.Substring(resultStr.IndexOf("<observationalastronomy>"),
                                                       (resultStr.IndexOf("</observationalastronomy>") + 25) - resultStr.IndexOf("<observationalastronomy>"));
                        resultsXmlStr = resultsXmlStr.Substring(0, resultsXmlStr.IndexOf("<observationalastronomy>")) +
                                        resultStr +
                                        resultsXmlStr.Substring(resultsXmlStr.IndexOf("<observationalastronomy>"));
                    }
                }
                catch (System.Exception ex) {
                    sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On transformIntoXmlDoc 'OEC transform' *** Exception: "
                                                         + ex.Message + " *** "
                                                         + ex.StackTrace);
                    sw.Flush();
                }
            }
            if (keyStr.Equals("OEC_XML")) {
                // Transform OAC_XML results and add to resultsXmlStr
                try {
                    // Create an XPathDocument using the XML string
                    StringReader stream = new StringReader(valueStr);
                    XPathDocument xpathDoc = new XPathDocument(stream);
                    // Create the new transform object
                    XslCompiledTransform transform = new XslCompiledTransform();

                    // Collect the resulting transformed XML in StringBuilder object
                    StringBuilder resultString = new StringBuilder();
                    XmlWriter writer = XmlWriter.Create(resultString);
                    transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\oecQuery.xslt");
                    transform.Transform(xpathDoc, writer);

                    // String to store the resulting transformed XML
                    resultStr = resultString.ToString();
                    resultStr = resultStr.Replace("utf-16", "utf-8");
                    resultStr = resultStr.Replace("![CDATA[", "");
                    resultStr = resultStr.Replace("]]", "");

                    // Add to resultsXmlStr
                    if (resultsXmlStr.Equals("")) resultsXmlStr = resultStr;
                    else {
                        // Insert into existing text string
                        resultStr = resultStr.Substring(resultStr.IndexOf("<observationalastronomy>"),
                                                       (resultStr.IndexOf("</observationalastronomy>") + 25) - resultStr.IndexOf("<observationalastronomy>"));
                        resultsXmlStr = resultsXmlStr.Substring(0, resultsXmlStr.IndexOf("<observationalastronomy>")) +
                                        resultStr +
                                        resultsXmlStr.Substring(resultsXmlStr.IndexOf("<observationalastronomy>"));
                    }
                }
                catch (System.Exception ex) {
                    sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On transformIntoXmlDoc 'OEC_XML transform' *** Exception: "
                                                         + ex.Message + " *** "
                                                         + ex.StackTrace);
                    sw.Flush();
                }
            }
        }

        // Create XMLDocument from resultsXmlStr
        resultsXmlDoc = new XmlDocument();
        resultsXmlDoc.LoadXml(resultsXmlStr);

        return resultsXmlDoc;
    }

}

       











