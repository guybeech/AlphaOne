﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Data;
using System.Collections;

/// <summary>
/// Queries databases and puts all results into a SortedList
/// </summary>
public class Query {
    // CENTRALISED VARIABLES
    private SortedList resultsList;


    public Query() {
    }


    /// <summary>
    /// Collects query results into a list
    /// </summary>
    /// <returns>SortedList</returns>
    public SortedList queryAllSelectedDatasources(SortedList lstSelectedDatasources, StreamWriter sw) {

        try {
            sw.WriteLine("Querying for data...");
            sw.WriteLine("");
            // For each selected database (in selected database list) send query, retrieve response and collect into the SortedList
            resultsList = new SortedList();
            IEnumerator databasesEnum = lstSelectedDatasources.GetEnumerator();
            while (databasesEnum.MoveNext()) {
                DictionaryEntry dataSourceEntry = (DictionaryEntry)databasesEnum.Current;
                if (dataSourceEntry.Key.ToString() == "Mast") {
                    sw.WriteLine("Querying for Mast");
                    string resultsMastStr = getMastData(dataSourceEntry.Value.ToString());
                    resultsList.Add("Mast", resultsMastStr);
                }
                if (dataSourceEntry.Key.ToString() == "Simbad") {
                    sw.WriteLine("Querying for Simbad");
                    string resultsSimbadStr = getSimbadData(dataSourceEntry.Value.ToString());
                    resultsList.Add("Simbad", resultsSimbadStr);
                }
                if (dataSourceEntry.Key.ToString() == "OEC") {
                    sw.WriteLine("Querying for OEC");
                    string resultsOECStr = getOecData(dataSourceEntry.Value.ToString());
                    resultsList.Add("OEC", resultsOECStr);
                }
                if (dataSourceEntry.Key.ToString() == "OEC_XML") {
                    sw.WriteLine("Querying for OEC_XML");
                    string resultsOECStr = getOecXmlData(dataSourceEntry.Value.ToString());
                    resultsList.Add("OEC_XML", resultsOECStr);
                }
            }
            return resultsList;
        }
        catch (Exception ex) {
            sw.WriteLine("*** queryAllSelectedDatasources ERROR ***", DateTime.Now + " : ERROR during database querying: " + ex.Message);
            resultsList.Add("ERROR", DateTime.Now + " : ERROR during database querying: " + ex.Message);
            return resultsList; 
        }
    }


    /// <summary>
    /// Requests data from website search
    /// </summary>
    /// <param name="queryStr"></param>
    /// <returns>The data in a string</returns>
    public string getOecData(string queryStr) {
        string outputStr = "";
        string urlAddress = queryStr;

        //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
        HttpWebRequest request = WebRequest.Create(urlAddress) as HttpWebRequest;
        //request.Proxy = webproxy;
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream receiveStream = response.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        // Pipes the stream to a higher level stream reader with the required encoding format. 
        StreamReader readStream = new StreamReader(receiveStream, encode);
        Char[] read = new Char[256];
        // Reads 256 characters at a time.     
        int count = readStream.Read(read, 0, 256);
        while (count > 0) {
            // Adds the 256 characters onto a string.
            String str = new String(read, 0, count);
            outputStr = outputStr + str;
            count = readStream.Read(read, 0, 256);
        }
        // Releases the resources of the response.
        response.Close();
        // Releases the resources of the Stream.
        readStream.Close();
        // Configure string for XSLT use
        string dateStr = DateTime.Today.ToShortDateString().Replace("/", " ");
        //Trim faulty returned data
        outputStr = outputStr.Substring(outputStr.IndexOf("<h3>Planet sizes</h3>"));
        outputStr = outputStr.Substring(0, outputStr.IndexOf("<!-- ########################### -->"));
        outputStr = outputStr.Replace("\"\"", "\"");
        outputStr = outputStr.Replace("red\" /><g style=\"stroke:black;\">", "red\" /><g style=\"stroke:black\"/>");

        outputStr = "<root><device>OEC</device><location>GITHUB</location><target>Tau Ceti</target><targetephemeris></targetephemeris><datetime>"
                    + dateStr +
                    "</datetime><weather></weather><observer></observer><data><![CDATA[" + outputStr + "]]></data><datatype>HTML</datatype><images></images><comments>For furthur info check the data</comments></root>";

        return outputStr;
    }


    /// <summary>
    /// Requests data from website search
    /// </summary>
    /// <param name="queryStr"></param>
    /// <returns>The data in a string</returns>
    public string getOecXmlData(string queryStr) {
        string outputStr = "";
        string urlAddress = queryStr;

        //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
        HttpWebRequest request = WebRequest.Create(urlAddress) as HttpWebRequest;
        //request.Proxy = webproxy;
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream receiveStream = response.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        // Pipes the stream to a higher level stream reader with the required encoding format. 
        StreamReader readStream = new StreamReader(receiveStream, encode);
        Char[] read = new Char[256];
        // Reads 256 characters at a time.     
        int count = readStream.Read(read, 0, 256);
        while (count > 0) {
            // Adds the 256 characters onto a string.
            String str = new String(read, 0, count);
            outputStr = outputStr + str;
            count = readStream.Read(read, 0, 256);
        }
        // Releases the resources of the response.
        response.Close();
        // Releases the resources of the Stream.
        readStream.Close();
        // Configure string for XSLT use
        string dateStr = DateTime.Today.ToShortDateString().Replace("/", " ");
        outputStr = "<root><device>OEC</device><location>GITHUB</location><target>Tau Ceti</target><targetephemeris></targetephemeris><datetime>"
                    + dateStr +
                    "</datetime><weather></weather><observer></observer><data><![CDATA[" + outputStr + "]]></data><datatype>XML</datatype><images></images><comments>For furthur info check the data</comments></root>";

        return outputStr;
    }


    /// <summary>
    /// Requests data from website search
    /// </summary>
    /// <param name="queryStr"></param>
    /// <returns>The data in a string</returns>
    public string getMastData(string queryStr) {
        string outputStr = "";
        string urlAddress = queryStr;

        //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
        HttpWebRequest request = WebRequest.Create(urlAddress) as HttpWebRequest;
        //request.Proxy = webproxy;
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream receiveStream = response.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        // Pipes the stream to a higher level stream reader with the required encoding format. 
        StreamReader readStream = new StreamReader(receiveStream, encode);
        Char[] read = new Char[256];
        // Reads 256 characters at a time.     
        int count = readStream.Read(read, 0, 256);
        while (count > 0) {
            // Adds the 256 characters onto a string.
            String str = new String(read, 0, count);
            outputStr = outputStr + str;
            count = readStream.Read(read, 0, 256);
        }
        // Releases the resources of the response.
        response.Close();
        // Releases the resources of the Stream.
        readStream.Close();
        // Configure string for XSLT use
        string dateStr = DateTime.Today.ToShortDateString().Replace("/", " ");
        outputStr = "<root><device>MAST Repository</device><location>USA</location><target>Tau Ceti</target><targetephemeris></targetephemeris><datetime>"
                    + dateStr +
                    "</datetime><weather></weather><observer></observer><data>" + outputStr + "</data><datatype>CSV</datatype><images></images><comments>For furthur info check the data</comments></root>";

        return outputStr;
    }


    /// <summary>
    /// Requests data from website search
    /// </summary>
    /// <param name="queryStr"></param>
    /// <returns>The data in a string</returns>
    public string getSimbadData(string queryStr) {
        string outputStr = "";
        string urlAddress = queryStr;

        //WebProxy webproxy = new WebProxy("http://161.112.232.103:3128");
        HttpWebRequest request = WebRequest.Create(urlAddress) as HttpWebRequest;
        //request.Proxy = webproxy;
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream receiveStream = response.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        // Pipes the stream to a higher level stream reader with the required encoding format. 
        StreamReader readStream = new StreamReader(receiveStream, encode);
        Char[] read = new Char[256];
        // Reads 256 characters at a time.     
        int count = readStream.Read(read, 0, 256);
        while (count > 0) {
            // Adds the 256 characters onto a string.
            String str = new String(read, 0, count);
            outputStr = outputStr + str;
            count = readStream.Read(read, 0, 256);
        }
        // Releases the resources of the response.
        response.Close();
        // Releases the resources of the Stream.
        readStream.Close();
        // First truncate SIMDAD result to only contain SIMBAD target star link data
        outputStr = outputStr.Substring(outputStr.IndexOf("#notes"));
        outputStr = outputStr.Substring(outputStr.IndexOf("http") - 1,
                                      (outputStr.IndexOf(">*")) - (outputStr.IndexOf("http") - 1));
        // Configure string for XSLT use
        string dateStr = DateTime.Today.ToShortDateString().Replace("/", " ");
        outputStr = "<root><device>SIMBAD</device><location>Strasbourg</location><target>Tau Ceti</target><targetephemeris></targetephemeris><datetime>"
                    + dateStr +
                    "</datetime><weather></weather><observer></observer><data><![CDATA[" + outputStr + "]]></data><datatype>SIMBADHTML</datatype><images></images><comments>For furthur info check the data</comments></root>";

        return outputStr;
    }

}

