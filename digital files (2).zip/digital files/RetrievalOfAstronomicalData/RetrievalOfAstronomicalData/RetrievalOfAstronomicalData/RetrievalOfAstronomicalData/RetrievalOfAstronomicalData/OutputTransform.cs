﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Data;
using System.Collections;
using System.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Xml.Xsl;
using System.Xml.Linq;

public class OutputTransform {
    // CENTRALISED VARIABLES
    XmlDocument resultsXmlDoc;
    string resultsXmlStr = "";
    string htmlTransformStr = "";
    string pdfTransformStr = "";
    private StreamWriter sw2;


    public OutputTransform() {
    }


    /// <summary>
    /// Calls the required output processes
    /// </summary>
    /// <param name="chosenOutputs"></param>
    /// <param name="dataDoc"></param>
    /// <param name="sw"></param>
    public void createOutputs(SortedList chosenOutputs, XmlDocument dataDoc, StreamWriter sw) {
        try {
            sw.WriteLine("");
            sw.WriteLine("Getting output choices...");
            // For each selected output choice, do transforms and create output file 
            IEnumerator outputsEnum = chosenOutputs.GetEnumerator();
            while (outputsEnum.MoveNext()) {
                DictionaryEntry outputEntry = (DictionaryEntry)outputsEnum.Current;
                if (outputEntry.Key.ToString() == "PDF") {
                    sw.WriteLine("");
                    sw.WriteLine("Choosing PDF");
                    outputPdf(dataDoc, sw);
                }
                if (outputEntry.Key.ToString() == "HTML") {
                    sw.WriteLine("");
                    sw.WriteLine("Choosing HTML");
                    outputHtml(dataDoc, sw);
                }
                if (outputEntry.Key.ToString() == "Machine") {
                    sw.WriteLine("");
                    sw.WriteLine("Choosing Machine");
                    outputMachine(dataDoc, sw);
                }
            }

        }
        catch (Exception ex) {
            sw.WriteLine("*** getChosenOutputs ERROR ***", DateTime.Now + " : ERROR during creation of output files: " + ex.Message);
        }

    }


    /// <summary>
    /// Creates HTML file using xmlDocument
    /// </summary>
    public void outputHtml(XmlDocument dataDoc, StreamWriter sw) {
        // Get the contents of the <data> tags
        // Assemble them into an HTML page using an XSLT file if necessary
        // Save to file

        // Transform 
        try {
            // Create an XPathDocument using the XML string
            string tempStr2 = dataDoc.OuterXml;
            tempStr2 = tempStr2.Replace("![CDATA[", "");
            tempStr2 = tempStr2.Replace("]]", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti b</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti c</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti d</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti e</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti f</name>", "");

            // Reset xml tags for OEC_XML
            string tempStr3 = tempStr2.Substring(tempStr2.IndexOf("&lt;system&gt;"),
                                                 (tempStr2.IndexOf("&lt;/system&gt;") + 15) - tempStr2.IndexOf("&lt;system&gt;"));
            tempStr3 = tempStr3.Replace("&lt;", "<");
            tempStr3 = tempStr3.Replace("&gt;", ">");
            tempStr2 = tempStr2.Substring(0, tempStr2.IndexOf("&lt;system&gt;")) +
                       tempStr3 +
                       tempStr2.Substring(tempStr2.IndexOf("&lt;/system&gt;") + 15);

            StringReader stream = new StringReader(tempStr2);
            XPathDocument xpathDoc = new XPathDocument(stream);
            // Create the new transform object
            XslCompiledTransform transform = new XslCompiledTransform();

            // Collect the resulting transformed XML in StringBuilder object

            StringBuilder resultString = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(resultString);
            transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\htmlOutput.xslt");
            transform.Transform(xpathDoc, writer);

            // String to store the resulting transformed XML
            htmlTransformStr = resultString.ToString();
            htmlTransformStr = htmlTransformStr.Replace("&lt;", "<");
            htmlTransformStr = htmlTransformStr.Replace("&gt;", ">");
            htmlTransformStr = htmlTransformStr.Replace("%20", " ");
            htmlTransformStr = htmlTransformStr.Replace("%40", "@");
            htmlTransformStr = htmlTransformStr.Replace("utf-16", "utf-8");

            // Format Mast data from csv type to html table compliant
            if (htmlTransformStr.Contains("MAST")) {
                string tempStr = htmlTransformStr.Substring(htmlTransformStr.IndexOf("<Table>") + 7,
                                                            htmlTransformStr.IndexOf("</Table>") - (htmlTransformStr.IndexOf("<Table>") + 7));
                string[] tempStrArray = tempStr.Split('\n');
                IEnumerator tempEnum = tempStrArray.GetEnumerator();
                string changedStr = "";
                int counter = 0;
                while (tempEnum.MoveNext()) {
                    if (counter != 1) changedStr = changedStr + "<tr>";
                    string rowStr = (string)tempEnum.Current;
                    rowStr = rowStr.Replace("\r", "");
                    string[] rowStrArray = rowStr.Split(',');
                    IEnumerator tempRowEnum = rowStrArray.GetEnumerator();
                    while (tempRowEnum.MoveNext()) {
                        if (counter == 0) {
                            changedStr = changedStr + "<th>" + (string)tempRowEnum.Current + "</th>";
                        }
                        if (counter > 1) {
                            changedStr = changedStr + "<td>" + (string)tempRowEnum.Current + "</td>";
                        }
                    }
                    if (counter != 1) changedStr = changedStr + "</tr>";
                    counter++;
                }

                htmlTransformStr = htmlTransformStr.Substring(0, htmlTransformStr.IndexOf("<Table>") + 7) +
                                   changedStr +
                                   htmlTransformStr.Substring(htmlTransformStr.IndexOf("</Table>"));
            }
            // Save to file
            string timeStr = DateTime.Now.ToString();
            timeStr = timeStr.Replace("/", " ");
            timeStr = timeStr.Replace(":", "-");
            // Incorporate date time into file name
            string path = "C://roadLogs//outputs//htmlOutput_" + timeStr + ".html";
            // Create new folder if not exists.
            if (Directory.Exists("C://roadLogs//outputs") == false) {
                DirectoryInfo dir = Directory.CreateDirectory("C://roadLogs//outputs");
            }
            File.WriteAllText(@"C://roadLogs//outputs//htmlOutput_" + timeStr + ".html", htmlTransformStr);

            // Create a new stream to write to the text log file
            sw.WriteLine("htmlOutput created: " + "C://roadLogs//outputs//htmlOutput_" + timeStr + ".html");
            sw.WriteLine("");
        }
        catch (System.Exception ex) {
            sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On OutputTransform.outputHtml 'htmlOutput transform' *** Exception: "
                                                 + ex.Message + " *** "
                                                 + ex.StackTrace);
            sw.Flush();
        }
    }


    /// <summary>
    /// Creates PDF file using xmlDocument
    /// </summary>
    public void outputPdf(XmlDocument dataDoc, StreamWriter sw) {
        // An XSL-FO transform is to be used here
        // Save to file

        // Transform 
        try {
            // Create an XPathDocument using the XML string
            string tempStr2 = dataDoc.OuterXml;
            tempStr2 = tempStr2.Replace("![CDATA[", "");
            tempStr2 = tempStr2.Replace("]]", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti b</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti c</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti d</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti e</name>", "");
            tempStr2 = tempStr2.Replace("<name>tau Ceti f</name>", "");

            // Reset xml tags for OEC_XML
            string tempStr3 = tempStr2.Substring(tempStr2.IndexOf("&lt;system&gt;"),
                                                 (tempStr2.IndexOf("&lt;/system&gt;") + 15) - tempStr2.IndexOf("&lt;system&gt;"));
            tempStr3 = tempStr3.Replace("&lt;", "<");
            tempStr3 = tempStr3.Replace("&gt;", ">");
            tempStr2 = tempStr2.Substring(0, tempStr2.IndexOf("&lt;system&gt;")) +
                       tempStr3 +
                       tempStr2.Substring(tempStr2.IndexOf("&lt;/system&gt;") + 15);

            StringReader stream = new StringReader(tempStr2);
            XPathDocument xpathDoc = new XPathDocument(stream);
            // Create the new transform object
            XslCompiledTransform transform = new XslCompiledTransform();

            // Collect the resulting transformed XML in StringBuilder object
            StringBuilder resultString = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(resultString);
            transform.Load("C:\\ROAD\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\RetrievalOfAstronomicalData\\pdfOutput.xslt");
            transform.Transform(xpathDoc, writer);

            // String to store the resulting transformed XML
            pdfTransformStr = resultString.ToString();
            pdfTransformStr = pdfTransformStr.Replace("&lt;", "<");
            pdfTransformStr = pdfTransformStr.Replace("&gt;", ">");
            pdfTransformStr = pdfTransformStr.Replace("%20", " ");
            pdfTransformStr = pdfTransformStr.Replace("%40", "@");
            pdfTransformStr = pdfTransformStr.Replace("utf-16", "utf-8");
            pdfTransformStr = pdfTransformStr.Replace("<svg", "<svg xmlns:svg=\"http://www.w3.org/2000/svg\"");

            // Format Mast data from csv type to html table compliant
            if (pdfTransformStr.Contains("MAST")) {
                string tempStr = pdfTransformStr.Substring(pdfTransformStr.IndexOf("Dataset,Target Name"),
                                                            pdfTransformStr.IndexOf("</fo:table></fo:flow>") - (pdfTransformStr.IndexOf("Dataset,Target Name")));
                string[] tempStrArray = tempStr.Split('\n');
                IEnumerator tempEnum = tempStrArray.GetEnumerator();
                string changedStr = "";
                int counter = 0;
                int numberOfColumns = 0;
                while (tempEnum.MoveNext()) {
                    if (counter != 1) changedStr = changedStr + "<fo:table-row>";
                    string rowStr = (string)tempEnum.Current;
                    rowStr = rowStr.Replace("\r", "");
                    string[] rowStrArray = rowStr.Split(',');
                    IEnumerator tempRowEnum = rowStrArray.GetEnumerator();
                    while (tempRowEnum.MoveNext()) {
                        if (counter == 0) {
                            numberOfColumns++;
                            changedStr = changedStr + "<fo:table-cell><fo:block color=\"blue\" font-weight=\"bold\">" + (string)tempRowEnum.Current + "</fo:block></fo:table-cell>";
                        }
                        if (counter > 1) {
                            changedStr = changedStr + "<fo:table-cell><fo:block>" + (string)tempRowEnum.Current + "</fo:block></fo:table-cell>";
                        }
                    }
                    if (counter != 1) changedStr = changedStr + "</fo:table-row>";
                    counter++;
                }
                // Create string for table column creation
                string columnCreationStr = "";
                for (int i = 1; i < numberOfColumns; i++) {
                    columnCreationStr = columnCreationStr + "<fo:table-column column-width=\"15mm\"/>";
                }
                pdfTransformStr = pdfTransformStr.Substring(0, pdfTransformStr.IndexOf("Dataset,Target Name")) +
                                  columnCreationStr +
                                  "<fo:table-body>" +
                                  changedStr +
                                  "</fo:table-body>" +
                                  pdfTransformStr.Substring(pdfTransformStr.IndexOf("</fo:table></fo:flow>"));
            }
            // Declare svg fully for xsl-fo transform
            if (pdfTransformStr.Contains("<svg")) {
                pdfTransformStr = pdfTransformStr.Replace("<svg xmlns:svg=\"http://www.w3.org/2000/svg\" width=\"480\" height=\"400\">", "</fo:block><fo:block><fo:instream-foreign-object><svg:svg xmlns:svg=\"http://www.w3.org/2000/svg\" width=\"480\" height=\"400\">");
                pdfTransformStr = pdfTransformStr.Replace("</svg>", "</svg:svg></fo:instream-foreign-object></fo:block><fo:block font-size=\"10pt\" font-family=\"sans-serif\" line-height=\"15pt\" space-after.optimum=\"3pt\" text-align=\"center\">");
                pdfTransformStr = pdfTransformStr.Replace("<g style=\"stroke:black;\">", "<svg:g style=\"stroke:black;\">");
                pdfTransformStr = pdfTransformStr.Replace("<g>", "<svg:g>");
                pdfTransformStr = pdfTransformStr.Replace("</g>", "</svg:g>");
                pdfTransformStr = pdfTransformStr.Replace("<text", "<svg:text");
                pdfTransformStr = pdfTransformStr.Replace("</text>", "</svg:text>");
                pdfTransformStr = pdfTransformStr.Replace("<circle", "<svg:circle");
                pdfTransformStr = pdfTransformStr.Replace("<line", "<svg:line");
                pdfTransformStr = pdfTransformStr.Replace("style=\"fill:url(#g2); stroke:none\"", "fill=\"lightgrey\"");
                pdfTransformStr = pdfTransformStr.Replace("style=\"fill:url(#g3); stroke:none\"", "ill=\"brown\"");
                pdfTransformStr = pdfTransformStr.Replace("ellipse", "svg:ellipse");
                pdfTransformStr = pdfTransformStr.Replace("<svg xmlns:svg=\"http://www.w3.org/2000/svg\" width=\"600\" height=\"100\">", "</fo:block><fo:block><fo:instream-foreign-object><svg:svg xmlns:svg=\"http://www.w3.org/2000/svg\" width=\"600\" height=\"100\">");
                pdfTransformStr = pdfTransformStr.Replace("</fo:block></fo:flow></fo:page-sequence></fo:root>", "</fo:block></fo:flow></fo:page-sequence></fo:root>");
                pdfTransformStr = pdfTransformStr.Replace("<p>", "");
                pdfTransformStr = pdfTransformStr.Replace("</p>", "");
                pdfTransformStr = pdfTransformStr.Replace("<h3>", "");
                pdfTransformStr = pdfTransformStr.Replace("</h3>", "");               
                pdfTransformStr = pdfTransformStr.Replace("fill=\"url(#habitablegradient)\"", "fill=\"lightgreen\"");
                pdfTransformStr = pdfTransformStr.Replace("<g style=\"stroke:black\"/>", "<svg:g style=\"stroke:black\"/>");
            }
            // Save to file
            string timeStr = DateTime.Now.ToString();
            timeStr = timeStr.Replace("/", " ");
            timeStr = timeStr.Replace(":", "-");
            // Incorporate date time into file name
            string path = "C://roadLogs//outputs//pdfOutput_" + timeStr + ".fo";
            // Create new folder if not exists.
            if (Directory.Exists("C://roadLogs//outputs") == false) {
                DirectoryInfo dir = Directory.CreateDirectory("C://roadLogs//outputs");
            }
            File.WriteAllText(@"C://roadLogs//outputs//pdfOutput_" + timeStr + ".fo", pdfTransformStr);

            // Create a new stream to write to the text log file
            sw.WriteLine("pdfOutput created: " + "C://roadLogs//outputs//pdfOutput_" + timeStr + ".fo");
            sw.WriteLine("");
        }
        catch (System.Exception ex) {
            sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On OutputTransform.outputPdf 'pdfOutput transform' *** Exception: "
                                                 + ex.Message + " *** "
                                                 + ex.StackTrace);
            sw.Flush();
        }
    }


    /// <summary>
    /// Creates file suitable for machine transfer using xmlDocument
    /// </summary>
    public void outputMachine(XmlDocument dataDoc, StreamWriter sw) {
        // Just pass the XMLDocument through without alteration... as is machine readable
        // Save straight to file
        try {
            // Get XmlDocument string and write to file
            string tempStr2 = dataDoc.OuterXml;

            // Save to file
            string timeStr = DateTime.Now.ToString();
            timeStr = timeStr.Replace("/", " ");
            timeStr = timeStr.Replace(":", "-");
            // Incorporate date time into file name
            string path = "C://roadLogs//outputs//machineOutput_" + timeStr + ".xml";
            // Create new folder if not exists.
            if (Directory.Exists("C://roadLogs//outputs") == false) {
                DirectoryInfo dir = Directory.CreateDirectory("C://roadLogs//outputs");
            }
            File.WriteAllText(@"C://roadLogs//outputs//machineOutput_" + timeStr + ".xml", tempStr2);

            // Create a new stream to write to the text log file
            //sw2 = File.AppendText(path);
            //sw2.Write(htmlTransformStr);
            sw.WriteLine("machineOutput created: " + "C://roadLogs//outputs//machineOutput_" + timeStr + ".xml");
            sw.WriteLine("");
        }
        catch (System.Exception ex) {
            sw.WriteLine(DateTime.Now.ToString() + "*** ERROR On OutputTransform.outputMachine 'machineOutput transform' *** Exception: "
                                                 + ex.Message + " *** "
                                                 + ex.StackTrace);
            sw.Flush();
        }
    }

}
